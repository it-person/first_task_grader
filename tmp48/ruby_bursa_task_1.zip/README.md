
## How to check if the task is completed ?

git clone git@github.com:it-person/ruby_bursa_task_1.git

cd ruby_bursa_task_1

bundle install

rspec library_manager_spec.rb

rspec library_manager_spec.rb -f documentation --colour


