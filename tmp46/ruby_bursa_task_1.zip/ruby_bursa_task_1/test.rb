puts 'hello world'
t = Time.now
t2 = t - 48.hours
puts t2