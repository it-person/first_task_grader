class LibraryManager


  # 1. Бибилиотека в один момент решила ввести жесткую систему штрафов (прямо как на rubybursa :D).
  # За каждый час опоздания со здачей книги читатель вынужден заплатить пеню 0,1% от стоимости.  
  # Необходимо реализовать метод, который будет считать эту сумму в зависимости от даты выдачи и 
  # текущего времени. По работе с датой-временем информацию можно посмотреть 
  # тут http://ruby-doc.org/stdlib-2.2.2/libdoc/date/rdoc/DateTime.html
  # 
  # Входящие параметры метода 
  # - стоимость книги в центах, 
  # - дата и время возврата (момент, когда книга должна была быть сдана, в формате DateTime)
  # Возвращаемое значение 
  # - пеня в центах
  def penalty price, issue_datetime
    now_date = DateTime.now.new_offset(0)
    difference_in_time = (now_date.to_time - issue_datetime.to_time).to_i / 3600
    return 0 if difference_in_time < 0 || price < 0
    (price * 0.001 * difference_in_time).round  
  end

  # 2. Известны годы жизни двух писателей. Год рождения, год смерти. Посчитать, могли ли они чисто 
  # теоретически встретиться. Даже если один из писателей был в роддоме - это все равно считается встречей. 
  # Помните, что некоторые писатели родились и умерли до нашей эры - в таком случае годы жизни будут просто 
  # приходить со знаком минус.
  # 
  # Входящие параметры метода 
  # - год рождения первого писателя, 
  # - год смерти первого писателя, 
  # - год рождения второго писателя, 
  # - год смерти второго писателя.
  # Возвращаемое значение 
  # - true или false
  def could_meet_each_other? year_of_birth_first, year_of_death_first, year_of_birth_second, year_of_death_second
    lifetime1 = year_of_death_first - year_of_birth_first 
    lifetime2 = year_of_death_second - year_of_birth_second 
    
    case
      when year_of_death_first < year_of_birth_second
        return false
      when year_of_death_second < year_of_birth_first 
        return false
      when lifetime1 < 0
        return false
      when lifetime2 < 0
        return false
      when year_of_birth_first > year_of_birth_second
        if year_of_birth_second < year_of_death_first
          return true
        end
      when year_of_birth_second > year_of_birth_first
        if year_of_birth_first < year_of_death_second
          return true
        end
      when year_of_death_first == year_of_death_second && year_of_birth_first == year_of_birth_second
        return true
    end

  end

  # 3. Исходя из жесткой системы штрафов за опоздания со cдачей книг, читатели начали задумываться - а 
  # не дешевле ли будет просто купить такую же книгу...  Необходимо помочь читателям это выяснить. За каждый 
  # час опоздания со здачей книги читатель вынужден заплатить пеню 0,1% от стоимости.
  # 
  # Входящий параметр метода 
  # - стоимость книги в центах 
  # Возвращаемое значение 
  # - число полных дней, нак которые необходимо опоздать со здачей, чтобы пеня была равна стоимости книги.
  def days_to_buy price
    fineperhour = price * 0.001
    hour = 0.0
    loop do 
      price -= fineperhour
      hour += 1.0
      break if price <= 0
    end
    (hour/24).round
  end


  # 4. Для удобства иностранных пользователей, имена авторов книг на украинском языке нужно переводить в 
  # транслит. Транслитерацию должна выполняться согласно официальным 
  # правилам http://kyivpassport.com/transliteratio/
  
  # Входящий параметр метода 
  # - имя и фамилия автора на украинском. ("Іван Франко") 
  # Возвращаемое значение 
  # - имя и фамилия автора транслитом. ("Ivan Franko")
  def author_translit ukr_name
    h = { 
     "А" => "A", "а" => "a",
     "Б" => "B", "б" => "b",
     "В" => "V", "в" => "v",
     "Г" => "H", "г" => "h",
     "Ґ" => "G", "ґ" => "g",
     "Д" => "D", "д" => "d",
     "Е" => "E", "е" => "e",
     "Є" => "Ye", "є" => "ie",
     "Ж" => "Zh", "ж" => "zh",
     "З" => "Z", "з" => "z",
     "И" => "Y", "и" => "y",
     "І" => "I", "і" => "i",
     "Ї" => "Yi", "ї" => "i",
     "Й" => "Y", "й" => "i",
     "К" => "K", "к" => "k",
     "Л" => "L", "л" => "l",
     "М" => "M", "м" => "m",
     "Н" => "N", "н" => "n",
     "О" => "O", "о" => "o",
     "П" => "P", "п" => "p",
     "Р" => "R", "р" => "r",
     "С" => "S", "с" => "s",
     "Т" => "T", "т" => "t",
     "У" => "U", "у" => "u",
     "Ф" => "F", "ф" => "f",
     "Х" => "Kh", "х" => "kh",
     "Ц" => "Ts", "ц" => "ts",
     "Ч" => "Ch", "ч" => "ch",
     "Ш" => "Sh", "ш" => "sh",
     "Щ" => "Shch", "щ" => "shch",
     "Ю" => "Yu", "ю" => "iu",
     "Я" => "Ya", "я" => "ia" 
   }

   return ukr_name.gsub(/[АаБбВвГгҐґДдЕеЄєЖжЗзИиІіЇїЙйКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЮюЯя]/, h)

  end

  #5. Читатели любят дочитывать книги во что-бы то ни стало. Необходимо помочь им просчитать сумму штрафа, 
  # который придеться заплатить чтобы дочитать книгу, исходя из количества страниц, текущей страницы и 
  # скорости чтения за час.
  # 
  # Входящий параметр метода 
  # - Стоимость книги в центах
  # - DateTime сдачи книги (может быть как в прошлом, так и в будущем)
  # - Количество страниц в книге
  # - Текущая страница
  # - Скорость чтения - целое количество страниц в час.
  # Возвращаемое значение 
  # - Пеня в центах или 0 при условии что читатель укладывается в срок здачи.
  def penalty_to_finish price, issue_datetime, pages_quantity, current_page, reading_speed
    left_pages_to_read = pages_quantity - current_page
    return 0 if reading_speed <= 0 || left_pages_to_read < 0
    left_time_to_read = left_pages_to_read / reading_speed
    now_date = DateTime.now.new_offset(0)
    difference_in_time = (now_date.to_time - issue_datetime.to_time).to_i / 3600
    if difference_in_time > 0
       ((difference_in_time + left_time_to_read) * price * 0.001).round
      else 
        difference_in_time = difference_in_time * (-1)
        if difference_in_time > left_time_to_read
          return 0
        else ((left_time_to_read - difference_in_time) * price * 0.001).round
        end
    end    

  end

end
