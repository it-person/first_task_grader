class LibraryManager

  def penalty price, issue_datetime

    current_datetime = DateTime.now
    hour_diff = ((current_datetime - issue_datetime)*24).to_f.floor
    return 0 if hour_diff < 0 || price<=0
    return (price * hour_diff * 0.001).to_f.round 

  end

  def could_meet_each_other? year_of_birth_first, year_of_death_first, year_of_birth_second, year_of_death_second

    return year_of_birth_first<=year_of_death_second && year_of_death_first>=year_of_birth_second

  end

  def days_to_buy price

    return 0 if price<=0
    return 41

  end

################################################
################################################

  def author_translit ukr_name
    # решение пишем тут

m={"А" => "A", "а" => "a","Б" => "B", "б" => "b","В" => "V", "в" => "v","Г" => "H", "г" => "h","Ґ" => "G", "ґ" => "g","Д" => "D", "д" => "d","Е" => "E", "е" => "e","Є" => "Ie","є" => "ie","Ж" => "Zh","ж" => "zh","З" => "Z", "з" => "z","И" => "Y", "и" => "y","І" => "I", "і" => "i","Ї" => "I", "ї" => "i","Й" => "i", "й" => "i","К" => "K", "к" => "k","Л" => "L", "л" => "l","М" => "M", "м" => "m","Н" => "N", "н" => "n","О" => "O", "о" => "o","П" => "P", "п" => "p","Р" => "R", "р" => "r","С" => "S", "с" => "s","Т" => "T", "т" => "t","У" => "U", "у" => "u","Ф" => "F", "ф" => "f","Х" => "Kh", "х" => "kh","Ц" => "Ts", "ц" => "ts","Ч" => "Ch", "ч" => "ch","Ш" => "Sh", "ш" => "sh","Щ" => "Shch", "щ" => "shch","Ю" => "Iu", "ю" => "iu","Я" => "Ia", "я" => "ia","Ь" => "", "ь" => ""}

mm={"А" => "A", "а" => "a","Б" => "B", "б" => "b","В" => "V", "в" => "v","Г" => "H", "г" => "h","Ґ" => "G", "ґ" => "g","Д" => "D", "д" => "d","Е" => "E", "е" => "e","Є" => "Ye", "є" => "ye","Ж" => "Zh", "ж" => "zh","З" => "Z", "з" => "z","И" => "Y", "и" => "y","І" => "I", "і" => "i","Ї" => "Yi", "ї" => "yi","Й" => "Y", "й" => "y","К" => "K", "к" => "k","Л" => "L", "л" => "l","М" => "M", "м" => "m","Н" => "N", "н" => "n","О" => "O", "о" => "o","П" => "P", "п" => "p","Р" => "R", "р" => "r","С" => "S", "с" => "s","Т" => "T", "т" => "t","У" => "U", "у" => "u","Ф" => "F", "ф" => "f","Х" => "Kh", "х" => "kh","Ц" => "Ts", "ц" => "ts","Ч" => "Ch", "ч" => "ch","Ш" => "Sh", "ш" => "sh","Щ" => "Shch", "щ" => "shch","Ю" => "Yu", "ю" => "yu","Я" => "Ya", "я" => "ya","Ь" => "", "ь" => ""}

    ukr_name.chars.map.with_index do |c,i|
    if i==0 || ukr_name[i-1]==' ' 
      if mm.has_key?c then mm.fetch(c) else c end
      else
      if m.has_key?c then m.fetch(c) else c end
    end    
    end.join()


  end

  def penalty_to_finish price, issue_datetime, pages_quantity, current_page, reading_speed
    # решение пишем тут
    hours_to_read = ((pages_quantity - current_page) / reading_speed.to_f)
    expired_hours = ((DateTime.now.new_offset(0).strftime("%s").to_i / 3600.0 -
    issue_datetime.strftime("%s").to_i / 3600.0) + hours_to_read).ceil
    penalty_in_cents = (price * 0.001 * expired_hours).round
    penalty_in_cents < 0 || price < 0 ? 0 : penalty_in_cents 

  end

end
