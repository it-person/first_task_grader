#coding: utf-8
require 'unicode'
#require 'active_support/all'
require 'pry'

class LibraryManager

  # 1. Бибилиотека в один момент решила ввести жесткую систему штрафов (прямо как на rubybursa :D).
  # За каждый час опоздания со здачей книги читатель вынужден заплатить пеню 0,1% от стоимости.  
  # Необходимо реализовать метод, который будет считать эту сумму в зависимости от даты выдачи и 
  # текущего времени. По работе с датой-временем информацию можно посмотреть 
  # тут http://ruby-doc.org/stdlib-2.2.2/libdoc/date/rdoc/DateTime.html
  # 
  # Входящие параметры метода 
  # - стоимость книги в центах, 
  # - дата и время возврата (момент, когда книга должна была быть сдана, в формате DateTime)
  # Возвращаемое значение 
  # - пеня в центах
  def penalty price, issue_datetime
    # решение пишем тут


    current = DateTime.now.new_offset(0)

    return 0 if price <= 0 || issue_datetime >= current 

    price_peny = price * 0.001

    total_hours = (current.to_time - issue_datetime.to_time).to_i / 3600
    total_peny = (total_hours * price_peny).round

    return total_peny
  end

  # 2. Известны годы жизни двух писателей. Год рождения, год смерти. Посчитать, могли ли они чисто 
  # теоретически встретиться. Даже если один из писателей был в роддоме - это все равно считается встречей. 
  # Помните, что некоторые писатели родились и умерли до нашей эры - в таком случае годы жизни будут просто 
  # приходить со знаком минус.
  # 
  # Входящие параметры метода 
  # - год рождения первого писателя, 
  # - год смерти первого писателя, 
  # - год рождения второго писателя, 
  # - год смерти второго писателя.
  # Возвращаемое значение 
  # - true или false
  def could_meet_each_other? year_of_birth_first, year_of_death_first, year_of_birth_second, year_of_death_second
    # решение пишем тут
    first = (year_of_birth_first..year_of_death_first).to_a
    second = (year_of_birth_second..year_of_death_second).to_a
    return (first & second).count>0 ? true : false
  end

  # 3. Исходя из жесткой системы штрафов за опоздания со cдачей книг, читатели начали задумываться - а 
  # не дешевле ли будет просто купить такую же книгу...  Необходимо помочь читателям это выяснить. За каждый 
  # час опоздания со здачей книги читатель вынужден заплатить пеню 0,1% от стоимости.
  # 
  # Входящий параметр метода 
  # - стоимость книги в центах 
  # Возвращаемое значение 
  # - число полных дней, нак которые необходимо опоздать со здачей, чтобы пеня была равна стоимости книги.
  def days_to_buy price
    # решение пишем тут
    return 0 if price <= 0
    return (price / (price * 0.001) / 24).round
  end


  # 4. Для удобства иностранных пользователей, имена авторов книг на украинском языке нужно переводить в 
  # транслит. Транслитерацию должна выполняться согласно официальным 
  # правилам http://kyivpassport.com/transliteratio/
  
  # Входящий параметр метода 
  # - имя и фамилия автора на украинском. ("Іван Франко") 
  # Возвращаемое значение 
  # - имя и фамилия автора транслитом. ("Ivan Franko")
  def author_translit ukr_name
    # решение пишем тут
#!!!!!     Нужно установить гем unicode
    dictionary = {"А"=>"A",
                  "а"=>"a",
                  "Б"=>"B",
                  "б"=>"b",
                  "В"=>"V",
                  "в"=>"v",
                  "Г"=>"H",
                  "г"=>"h",
                  "Ґ"=>"G",
                  "ґ"=>"g",
                  "Д"=>"D",
                  "д"=>"d",
                  "Е"=>"E",
                  "е"=>"e",
                  "Є"=>"Ye",
                  "є"=>"ie",
                  "Ж"=>"Zh",
                  "ж"=>"zh",
                  "З"=>"Z",
                  "з"=>"z",
                  "И"=>"Y",
                  "и"=>"y",
                  "І"=>"I",
                  "і"=>"i",
                  "Ї"=>"Yi",
                  "ї"=>"i",
                  "Й"=>"Y",
                  "й"=>"i",
                  "К"=>"K",
                  "к"=>"k",
                  "Л"=>"L",
                  "л"=>"l",
                  "М"=>"M",
                  "м"=>"m",
                  "Н"=>"N",
                  "н"=>"n",
                  "О"=>"O",
                  "о"=>"o",
                  "П"=>"P",
                  "п"=>"p",
                  "Р"=>"R",
                  "р"=>"r",
                  "С"=>"S",
                  "с"=>"s",
                  "Т"=>"T",
                  "т"=>"t",
                  "У"=>"U",
                  "у"=>"u",
                  "ф"=>"F",
                  "Ф"=>"f",
                  "Х"=>"Kh",
                  "х"=>"kh",
                  "Ц"=>"Ts",
                  "ц"=>"ts",
                  "Ч"=>"Ch",
                  "ч"=>"ch",
                  "Ш"=>"Sh",
                  "ш"=>"sh",
                  "Щ"=>"Shch",
                  "щ"=>"shch",
                  "Ю"=>"Yu",
                  "ю"=>"iu",
                  "Я"=>"Ya",
                  "я"=>"ia",
                  "’"=>"",
                  "'"=>"",
                  "`"=>""
                  }

    tmp_name = ""

# Убираем пробелы и подымаем первые буквы
    ukr_name.strip.split.each {|x|
      tmp_name <<  Unicode::capitalize(x) + " "
    }

    ukr_name = tmp_name.strip

    dictionary.each do |key, value|
      ukr_name = ukr_name.gsub(key,value)
    end

    return ukr_name
  end


  #5. Читатели любят дочитывать книги во что-бы то ни стало. Необходимо помочь им просчитать сумму штрафа, 
  # который придеться заплатить чтобы дочитать книгу, исходя из количества страниц, текущей страницы и 
  # скорости чтения за час.
  # 
  # Входящий параметр метода 
  # - Стоимость книги в центах
  # - DateTime сдачи книги (может быть как в прошлом, так и в будущем)
  # - Количество страниц в книге
  # - Текущая страница
  # - Скорость чтения - целое количество страниц в час.
  # Возвращаемое значение 
  # - Пеня в центах или 0 при условии что читатель укладывается в срок здачи.
  def penalty_to_finish price, issue_datetime, pages_quantity, current_page, reading_speed
    # решение пишем тут
    current = DateTime.now.new_offset(0)
    return 0 if price <= 0 || pages_quantity <= 0 || current_page <= 0 || (pages_quantity - current_page) <= 0

    left_seconds = (pages_quantity - current_page) / reading_speed * 3600
    left_time = current.to_time + left_seconds

    return 0 if issue_datetime >= left_time

    price_peny = price * 0.001
    total_hours = (left_time - issue_datetime.to_time).to_i / 3600

    total_peny = (total_hours * price_peny).round

    return total_peny
  end

end
